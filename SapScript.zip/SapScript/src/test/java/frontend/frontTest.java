package frontend;

import java.sql.*;
import backend.*;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.LinkedList;


import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

//package default;
import org.junit.jupiter.api.Test;

import backend.User;
import database.DB;    
    
public class frontTest {

/*
    //new user
    @Test
    public void testNewUser() {
        DB database = DB.getInstance();
        front f= new front ();
        database.connect();
        User jose = new User ("Jose", 2000, 'M', "+351910910910", "testjose@gmail.com","Admin");
        
        assertEquals(1 , f.newUser(database, jose, "jojo1", jose.getName(), jose.getyearBirth(), jose.getSex(), jose.getContact(), jose.getEmail(), jose.getRole(), "rococo"));
      
    }*/

/*
    //delet user from test new user
    @Test
    public void testQueryUserRemove() {
        DB database = DB.getInstance();
        front f= new front ();
        database.connect();

        assertEquals(1 , database.queryUserRemove("jojo1"));
    }*/


    //log in (corret acount)
    @Test
    public void testLogInT() {
        DB database = DB.getInstance();
        front f= new front ();
        database.connect();
        User jose = new User ("Jose", 2000, 'M', "+351910910910", "testjose@gmail.com","Admin");
        
        assertEquals(jose.getName() , f.login(database, "jojo",  "rococo").getName());
    }


    //log in (incorret acount)
    @Test
    public void testLogInF() {
        DB database = DB.getInstance();
        front f= new front ();
        database.connect();
        User jose = new User ("Jose", 2000, 'M', "+351910910910", "testjose@gmail.com","Admin");
        
        assertEquals(null , f.login(database, "jojo",  "ococor"));
    }

    //new suplier
    @Test
    public void testNewSupplier() {
        DB database = DB.getInstance();
        front f= new front ();
        database.connect();
        User jose = new User ("Jose", 2000, 'M', "+351910910910", "testjose@gmail.com","Admin");
        Supplier s = new Supplier("tests", "+351909090901", "test@gmail.com");
        assertEquals(1 ,database.querySupplierNew(s));
        database.querySupplierRemove("tests");
    }
/*
    //new product
    @Test
    public void testNewProduct() {
        DB database = DB.getInstance();
        front f= new front ();
        database.connect();
        User jose = new User ("Jose", 2000, 'M', "+351910910910", "testjose@gmail.com","Admin");
        Supplier s = new Supplier("test", "+351909090901", "test@gmail.com");
        database.querySupplierNew(s);
        assertEquals(1 ,f.newProduct (database, "test", "1", "test"));
//remove product needed
// database.querySupplierRemove("test");

    }*/


    //item input
    @Test
    public void testItemInput() {
        DB database = DB.getInstance();
        front f= new front ();
        database.connect();
        User jose = new User ("Jose", 2000, 'M', "+351910910910", "testjose@gmail.com","Admin");
          
        assertEquals(1 , f.itemInput(database, "78988", 1, 1, 1, 10));

        f.itemOutput(database, Integer.parseInt(f.getItemId(database,"030")) ,1);
    }

    //item output
    @Test
    public void testItemOutput() {
        DB database = DB.getInstance();
        front f= new front ();
        database.connect();
        User jose = new User ("Jose", 2000, 'M', "+351910910910", "testjose@gmail.com","Admin");

         f.itemInput(database, "78988", 1, 1, 1, 10);

        assertEquals(1 ,f.itemOutput(database, Integer.parseInt(f.getItemId(database,"030")) ,1));
    }


//search product (no product like that)
@Test
public void testSearchProductF() {
    DB database = DB.getInstance();
    front f= new front ();
    database.connect();
    User jose = new User ("Jose", 2000, 'M', "+351910910910", "testjose@gmail.com","Admin");
      
    assertEquals(null , f.searchProduct(database, "productNamexyz"));
}

    //search product (no product like that)
    @Test
    public void testSearchProductT() {
        DB database = DB.getInstance();
        front f= new front ();
        database.connect();
        User jose = new User ("Jose", 2000, 'M', "+351910910910", "testjose@gmail.com","Admin");

        assertNotNull(database.queryProductSearchName( "test"));
    }




}