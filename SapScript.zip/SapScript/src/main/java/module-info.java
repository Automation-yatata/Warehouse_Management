module gui.gui_bd {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.sql;


    opens gui.gui_bd to javafx.fxml;
    exports gui.gui_bd;
}