package gui.gui_bd;

import javafx.beans.property.SimpleStringProperty;

public class FileData2 {


    public SimpleStringProperty id;
    public SimpleStringProperty type;
    public SimpleStringProperty msg;
    public SimpleStringProperty logDate;

    public FileData2(String id, String t, String m, String l){
        this.id = new SimpleStringProperty(id);

        this.type=new SimpleStringProperty(t);
        this.msg=new SimpleStringProperty(m);
        this.logDate=new SimpleStringProperty(l);
    }
    public String getid(){
        return this.id.get();
    }
    public String getType(){
        return this.type.get();
    }
    public String getmsg(){
        return this.msg.get();
    }
    public String getlogDate(){
        return this.logDate.get();
    }

}
