package gui.gui_bd;

import java.io.IOException;
import java.net.URL;
//import java.sql.Connection;
//import java.sql.DriverManager;
//import java.sql.ResultSet;
import java.time.LocalDate;
import java.util.LinkedList;
import java.util.ResourceBundle;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
//import jdk.nashorn.internal.ir.Statement;

import frontend.*;
import database.*;
import backend.*;



public class LoginController implements Initializable {

    @FXML
    private Label label;

    @FXML
    private Label invalid_label;

    @FXML
    private TextField username_box;

    public  String getUsername_box(){
        return this.username_box.getText();
    }

    @FXML
    private TextField password_box;

    @FXML
    private void handleButtonAction(ActionEvent event) throws IOException {




        DB database = DB.getInstance();
        database.connect();

        front m = new front();

        User u = m.login (database, username_box.getText(), password_box.getText());
        //System.out.println(u.getName());
        if(u != null){
            TransmissionData data = TransmissionData.getInstance();
            data.setUserLogin(u);

            LocalDate date = LocalDate.now();
            database.queryLogNew("LOGIN", u.getName() + "  " + u.getEmail(),  date);


            Parent home_page_parent = FXMLLoader.load(getClass().getResource("HomeController.fxml"));
            Scene home_page_scene = new Scene(home_page_parent);
            Stage app_stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            app_stage.setScene(home_page_scene);
            app_stage.show();

        }
        else
        {

            LocalDate date = LocalDate.now();
            database.queryLogNew("ERROR", "Login Credentials",  date);

            username_box.clear();
            password_box.clear();
            invalid_label.setText("Sorry, invalid credentials");
        }
    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        /*DB database = DB.getInstance();
        database.connect();
        database.dropAll();
        database.setup();
        front f = new front();
        f.uploadTestData(database);*/
    }
}
