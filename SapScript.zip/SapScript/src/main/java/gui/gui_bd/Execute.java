package gui.gui_bd;

public class Execute {

    public static void main(String[] args) {
        App.main(args);
    }
}
