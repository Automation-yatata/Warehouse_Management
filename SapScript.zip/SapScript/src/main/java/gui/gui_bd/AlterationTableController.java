package gui.gui_bd;

public class AlterationTableController {
}
