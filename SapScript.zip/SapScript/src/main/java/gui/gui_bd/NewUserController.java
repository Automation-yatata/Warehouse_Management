package gui.gui_bd;


import backend.User;
import javafx.beans.Observable;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.text.Text;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.Calendar;
import java.util.LinkedList;

import frontend.*;
import database.*;

public class NewUserController {

    @FXML
    private TextField userName;
    @FXML
    private TextField Password;
    @FXML
    private TextField email;
    @FXML
    private ChoiceBox cargo;

    @FXML
    private TextField Nome;
    @FXML
    private TextField contacto;
    @FXML
    private DatePicker DataNasci;
    @FXML
    private TextField idadeField;
    @FXML
    private Label label;

    @FXML
    private ChoiceBox Sex;

    ObservableList<String> gender = FXCollections.observableArrayList("M", "F");
    ObservableList<String> role = FXCollections.observableArrayList("Admin", "Operator");


    front f = new front();
    DB d = DB.getInstance();


    @FXML
    private void Macho(){
        Sex.setItems(gender);
        label.setText("");
    }

    @FXML
    private void Cargo(){
        Sex.setItems(role);
    }


    @FXML    //adicionar
    private void AddButton(ActionEvent event) throws IOException {
        User A = new User("zeze", 2000, 'F', "911526625", "PI100PE@sapo.pt", "Admin");

        f.newUser(d, A, userName.getText(), Nome.getText(), DataNasci.getValue().getYear(), ((String) Sex.getSelectionModel().getSelectedItem()).charAt(0), contacto.getText(), email.getText(), (String) cargo.getSelectionModel().getSelectedItem(), Password.getText());
        label.setText("User created!");
        userName.clear();
        Password.clear();
        email.clear();
        Nome.clear();
        contacto.clear();
        idadeField.clear();
    }

    @FXML    //voltar
    private void BackButton(ActionEvent event) throws IOException {
        Parent home_page_parent = FXMLLoader.load(getClass().getResource("HomeController.fxml"));
        Scene home_page_scene = new Scene(home_page_parent);
        Stage app_stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        app_stage.setScene(home_page_scene);
        app_stage.show();
    }

    @FXML
    private void MostrarIdade(){
        Calendar now = Calendar.getInstance();
        int year = now.get(Calendar.YEAR);
        int birthYear = (DataNasci.getValue().getYear());
        int idade = year - birthYear;
        idadeField.setText(Integer.toString(idade) + " Anos");
    }



}
