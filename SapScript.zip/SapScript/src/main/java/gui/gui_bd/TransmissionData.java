package gui.gui_bd;

import backend.User;

public class TransmissionData {

    private final static TransmissionData single_instance = new TransmissionData();
    private User userLogin;



    private TransmissionData()
    {

    }

    public static TransmissionData getInstance() {
        return single_instance;
    }
    public User getUserLogin(){
        return this.userLogin;
    }
    public void setUserLogin (User u){

        this.userLogin = u;

    }
    public String getName(){
        return this.userLogin.getName();
    }

}
