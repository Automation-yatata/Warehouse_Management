package gui.gui_bd;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.time.LocalDate;
import java.util.LinkedList;
import java.util.ResourceBundle;

import database.*;
import frontend.*;

public class NewProductController implements Initializable {

    @FXML
    private ChoiceBox<String> iva;

    @FXML
    private ChoiceBox<String> supply;

    @FXML
    private TextField nome;

    @FXML
    private TextField ref;

    @FXML
    private Label label;

    @FXML
    private Label BADlabel;

    ObservableList<String> ivaList = FXCollections.observableArrayList("0%", "16%", "23%");

    front f = new front();
    DB d = DB.getInstance();

    @FXML
    private void init(){
        //Andar.setValue("0");
        iva.setItems(ivaList);

    }

    @FXML
    private void ListaSupply(){
        /*
        LinkedList<String> Nomes = f.getAllSupplierNames (d);
        ObservableList<String> SNomes = FXCollections.observableArrayList(Nomes);
        supply.setItems(SNomes);
        label.setText("");
        BADlabel.setText("");

         */
    }

    @FXML
    private void ADDButton(ActionEvent event) throws IOException {

        label.setText("");
        BADlabel.setText("");

        int i = f.newProduct(d, nome.getText(), ref.getText(), (String) supply.getSelectionModel().getSelectedItem());
        DB database = DB.getInstance();

        if (i == 1){
            LocalDate date = LocalDate.now();
            database.queryLogNew("NEW_PRODUCT", "N: " + nome.getText() + "R: " + ref.getText() + supply.getSelectionModel().getSelectedItem(),  date);

            label.setText("Product sheet created successfully!");
            nome.clear();
            ref.clear();
        }
        else if (i==0){
            BADlabel.setText("Product is already in the DataBase :(");
        }

        LinkedList<String> Nomes = f.getAllSupplierNames (d);
        ObservableList<String> SNomes = FXCollections.observableArrayList(Nomes);
        supply.setItems(SNomes);

    }

    @FXML
    private void BackButton(ActionEvent event) throws IOException {
        Parent home_page_parent = FXMLLoader.load(getClass().getResource("TransacaoController.fxml"));
        Scene home_page_scene = new Scene(home_page_parent);
        Stage app_stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        app_stage.setScene(home_page_scene);
        app_stage.show();
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        LinkedList<String> Nomes = f.getAllSupplierNames (d);
        ObservableList<String> SNomes = FXCollections.observableArrayList(Nomes);
        supply.setItems(SNomes);
        label.setText("");
        BADlabel.setText("");
    }
}
