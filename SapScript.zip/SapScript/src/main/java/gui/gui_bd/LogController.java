package gui.gui_bd;


import backend.Item;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.util.LinkedList;
import java.util.List;
import java.util.ResourceBundle;

import database.*;
import frontend.*;




public class LogController implements Initializable {




    @FXML
    private TableView logTable;

    @FXML
    private TableColumn<FileData2,String> col_id;

    @FXML
    private TableColumn<FileData2,String> col_type;
    @FXML
    private TableColumn<FileData2,String> col_msg;
    @FXML
    private TableColumn<FileData2,String> col_logDate;


    LinkedList<LinkedList<String>> logs;



    public void UpdateTable(LinkedList<LinkedList<String>> logs){

        //FileData f1 = new FileData(item.get(0),item.get(1),item.get(2),item.get(4),item.get(3));
        //FileData f2 = new FileData("2","3","5", "2","5");
        //System.out.println(item.get(0));
        //ObservableList<FileData> list = FXCollections.observableArrayList(f1);
        int i = 0;
        LinkedList exe = new LinkedList<FileData2>();
        while(i < logs.size()){
            FileData2 f1 = new FileData2(logs.get(i).get(0), logs.get(i).get(1), logs.get(i).get(2), logs.get(i).get(3));
            exe.add(f1);
            i++;
        }

        ObservableList<FileData> list = FXCollections.observableArrayList(exe);

        col_id.setCellValueFactory(dados -> new SimpleStringProperty(dados.getValue().getid()));
        col_type.setCellValueFactory(dados -> new SimpleStringProperty(dados.getValue().getType()));
        col_msg.setCellValueFactory(dados -> new SimpleStringProperty(dados.getValue().getmsg()));
        col_logDate.setCellValueFactory(dados-> new SimpleStringProperty(dados.getValue().getlogDate()));


        logTable.setItems(list);


    }


    @FXML
    private void BackButton(ActionEvent event) throws IOException {
        Parent home_page_parent = FXMLLoader.load(getClass().getResource("HomeController.fxml"));
        Scene home_page_scene = new Scene(home_page_parent);
        Stage app_stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        app_stage.setScene(home_page_scene);
        app_stage.show();
    }


    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {


        DB database = DB.getInstance();
        logs = database.queryGetAllLogs();

        this.UpdateTable(logs);


    }
}
