package gui.gui_bd;

import javafx.beans.property.SimpleStringProperty;

public class FileData {


    public SimpleStringProperty id;
    public SimpleStringProperty quantity;
    public SimpleStringProperty cost;
    public SimpleStringProperty rack_Id;
    public SimpleStringProperty inputDate;


    public FileData(String id, String q, String c, String r, String d){
        this.id=new SimpleStringProperty(id);
        this.quantity=new SimpleStringProperty(q);
        this.cost=new SimpleStringProperty(c);
        this.rack_Id=new SimpleStringProperty(r);
        this.inputDate=new SimpleStringProperty(d);
    }
    public String getid(){
        return id.get();
    }
    public String getrack_Id(){
        return rack_Id.get();
    }
    public String getquantity(){
        return quantity.get();
    }
    public String getcost(){
        return cost.get();
    }
    public String getinputDate(){
        return inputDate.get();
    }

}
