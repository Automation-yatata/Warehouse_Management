package gui.gui_bd;


import backend.Supplier;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.time.LocalDate;
import java.util.LinkedList;
import java.util.ResourceBundle;

import database.*;
import frontend.*;



public class NewSupplierController {


    @FXML
    private TextField inputName;

    @FXML
    private TextField inputContact;

    @FXML
    private TextField inputEmail;



    @FXML
    private Label labelConfimation;

    @FXML
    private void ADDButton(ActionEvent event) throws IOException {

        labelConfimation.setText("");


        Supplier s = new Supplier(inputName.getText(), inputContact.getText(), inputEmail.getText());
        DB d = DB.getInstance();

        if (d.querySupplierNew(s) == 1){

            labelConfimation.setText("Supplier Sheet Created Successfully!");

            LocalDate date = LocalDate.now();
            d.queryLogNew("NEW_SUPPLIER", "N: " + inputName.getText() + "  C: " + inputContact.getText() + "  E: " + inputEmail.getText(),  date);

            inputName.clear();
            inputContact.clear();
            inputEmail.clear();

        }else{

            labelConfimation.setText("Error Creating Supplier Sheet");

        }

    }

    @FXML
    private void BackButton (ActionEvent event) throws IOException {
        Parent home_page_parent = FXMLLoader.load(getClass().getResource("TransacaoController.fxml"));
        Scene home_page_scene = new Scene(home_page_parent);
        Stage app_stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        app_stage.setScene(home_page_scene);
        app_stage.show();
    }



}
