package gui.gui_bd;

import backend.Item;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.util.LinkedList;
import java.util.List;
import java.util.ResourceBundle;

import database.*;
import frontend.*;

public class PesquisaController  implements Initializable{


    @FXML
    private void BackButton(ActionEvent event) throws IOException {
        Parent home_page_parent = FXMLLoader.load(getClass().getResource("HomeController.fxml"));
        Scene home_page_scene = new Scene(home_page_parent);
        Stage app_stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        app_stage.setScene(home_page_scene);
        app_stage.show();
    }

    front m = new front();

    LinkedList<LinkedList <String>> items;

    @FXML
    public  LinkedList<String> getIds(LinkedList<LinkedList<String>> items){

        LinkedList<String> retorno = new LinkedList<>();
        int i =0;
        while(items.isEmpty() != false){
            retorno.add(items.get(i).get(0));
        }
        return retorno;
    }

    @FXML
    private TextField ProdutoNome;

    @FXML
    private ChoiceBox NomeProduct;

    @FXML
    private TableView table;

    @FXML
    private TableColumn<FileData,String> col_id;

    @FXML
    private TableColumn<FileData,String> col_quantity;

    @FXML
    private TableColumn<FileData,String> col_cost;

    @FXML
    private TableColumn<FileData,String> col_date;

    @FXML
    private TableColumn<FileData,String> col_rack;

    @FXML
    private Label info;

    DB d = DB.getInstance();

    public void UpdateTable(LinkedList<LinkedList<String>> item){

        //FileData f1 = new FileData(item.get(0),item.get(1),item.get(2),item.get(4),item.get(3));
        //FileData f2 = new FileData("2","3","5", "2","5");
        //System.out.println(item.get(0));
        //ObservableList<FileData> list = FXCollections.observableArrayList(f1);
        int i = 0;
        LinkedList exe = new LinkedList<FileData>();
        LinkedList<String> aux = new LinkedList<String>();

        if (item == null){

            info.setText("Producto Não se Encontra em Armazem");
            return;
        }else{
            info.setText("");
        }

        while(i < item.size()){

            aux = d.queryRackSearch(Integer.parseInt(item.get(i).get(4)));
            String pos = aux.get(1) + aux.get(2) + aux.get(3);

            FileData f1 = new FileData(item.get(i).get(0),item.get(i).get(1),item.get(i).get(2),pos,item.get(i).get(3));
            exe.add(f1);
            i++;
        }

        ObservableList<FileData> list = FXCollections.observableArrayList(exe);

        col_id.setCellValueFactory(dados -> new SimpleStringProperty(dados.getValue().getid()));
        col_quantity.setCellValueFactory(dados -> new SimpleStringProperty(dados.getValue().getquantity()));
        col_cost.setCellValueFactory(dados -> new SimpleStringProperty(dados.getValue().getcost()));
        col_date.setCellValueFactory(dados-> new SimpleStringProperty(dados.getValue().getinputDate()));
        col_rack.setCellValueFactory(dados -> new SimpleStringProperty(dados.getValue().getrack_Id()));

        table.setItems(list);


    }


    @FXML
    private void PesqButton(ActionEvent event) {
        DB db = DB.getInstance();
        db.connect();
        items = m.searchProduct(db, (String) NomeProduct.getSelectionModel().getSelectedItem());
        int i = 0;
        System.out.println(items);
        this.UpdateTable(items);

        /*while(i < items.size()){
            this.UpdateTable(items.get(i));
            i++;
        }*/

    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {

        LinkedList<String> Produtos = m.getAllProductnames (d);
        ObservableList<String> obsProdutos = FXCollections.observableArrayList(Produtos);
        NomeProduct.setItems(obsProdutos);

    }
}
