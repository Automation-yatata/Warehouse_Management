package gui.gui_bd;


import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;

import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.time.LocalDate;
import java.util.*;

import frontend.*;
import database.*;


public class TransacaoController implements Initializable {

    front m = new front();
    DB d = DB.getInstance();


    @FXML
    private ChoiceBox FiltroProduto;

    @FXML
    private ChoiceBox RackPosicaoInput;

    @FXML
    private ChoiceBox RackPosicaoOutput;

    @FXML
    private TextField QuantidadeADD;

    @FXML
    private TextField Custo;

    @FXML
    private TextField Peso;

    @FXML
    private TextField QuantidadeREMOVE;

    @FXML
    private Label Inserir_label;

    @FXML
    private Label Remover_label;


    @FXML
    private void inicio(){

        /*LinkedList<String> Produtos = m.getAllProductnames (d);
        ObservableList<String> obsProdutos = FXCollections.observableArrayList(Produtos);
        FiltroProduto.setItems(obsProdutos);
        */

        LinkedList<String> Posicao = m.getRackEmptyPosition (d);
        ObservableList<String> obsRacks = FXCollections.observableArrayList(Posicao);
        RackPosicaoInput.setItems(obsRacks);

        Inserir_label.setText("");
        Remover_label.setText("");
    }

    @FXML
    private void entradaRack(){
        /*
        LinkedList<String> Posicao = m.getRackEmptyPosition (d);
        ObservableList<String> obsRacks = FXCollections.observableArrayList(Posicao);
        RackPosicaoInput.setItems(obsRacks);
        */
    }

    @FXML
    private void saidaRack(){

        LinkedList<String> Posicao = m.getRackPosition (d, (String) FiltroProduto.getSelectionModel().getSelectedItem());
        ObservableList<String> obsRacks = FXCollections.observableArrayList(Posicao);
        RackPosicaoOutput.setItems(obsRacks);
    }


    @FXML
    private void AddCleanButton(ActionEvent event) {


        String ref = m.getProductRef(d, (String) FiltroProduto.getSelectionModel().getSelectedItem());
        System.out.println((String) RackPosicaoInput.getSelectionModel().getSelectedItem());
        int id = Integer.parseInt(m.getRackId(d, (String) RackPosicaoInput.getSelectionModel().getSelectedItem()));
        System.out.println(id);
        m.itemInput(d, ref, Double.parseDouble(QuantidadeADD.getText()), Double.parseDouble(Peso.getText()), Double.parseDouble(Custo.getText()), id);



        LocalDate date = LocalDate.now();
        d.queryLogNew("INPUT", "N:" + (String) FiltroProduto.getSelectionModel().getSelectedItem() + "  Q: " + QuantidadeADD.getText() + "  P: " + Peso.getText() + "  R: " + (String) RackPosicaoInput.getSelectionModel().getSelectedItem(),  date);


        LinkedList<String> Posicao = m.getRackEmptyPosition (d);
        ObservableList<String> obsRacks = FXCollections.observableArrayList(Posicao);
        RackPosicaoInput.setItems(obsRacks);



        QuantidadeADD.clear();
        Peso.clear();
        Custo.clear();
        Inserir_label.setText("Produto Inserido com Sucesso!");


    }



    @FXML
    private void RemoveCleanButton(ActionEvent event) throws IOException{
        m.itemOutput(d, Integer.parseInt(m.getItemId(d, (String) RackPosicaoOutput.getSelectionModel().getSelectedItem())), Integer.parseInt(QuantidadeREMOVE.getText()));

        LocalDate date = LocalDate.now();
        d.queryLogNew("OUTPUT", "N:" + (String) FiltroProduto.getSelectionModel().getSelectedItem() + " Q: " + QuantidadeREMOVE.getText() + " R: " + (String) RackPosicaoOutput.getSelectionModel().getSelectedItem(),  date);


        LinkedList<String> Posicao = m.getRackEmptyPosition (d);
        ObservableList<String> obsRacks = FXCollections.observableArrayList(Posicao);
        RackPosicaoInput.setItems(obsRacks);

        QuantidadeREMOVE.clear();
        Remover_label.setText("Produto Removido com Sucesso!");

    }

    @FXML
    private void BackButton(ActionEvent event) throws IOException {
        Parent home_page_parent = FXMLLoader.load(getClass().getResource("HomeController.fxml"));
        Scene home_page_scene = new Scene(home_page_parent);
        Stage app_stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        app_stage.setScene(home_page_scene);
        app_stage.show();
    }
    @FXML
    private void AddProductButton(ActionEvent event) throws IOException {
        Parent home_page_parent = FXMLLoader.load(getClass().getResource("AddProductController.fxml"));
        Scene home_page_scene = new Scene(home_page_parent);
        Stage app_stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        app_stage.setScene(home_page_scene);
        app_stage.show();
    }
    @FXML
    private void LessProductButton(ActionEvent event) throws IOException {
        Parent home_page_parent = FXMLLoader.load(getClass().getResource("RemoveProductController.fxml"));
        Scene home_page_scene = new Scene(home_page_parent);
        Stage app_stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        app_stage.setScene(home_page_scene);
        app_stage.show();
    }
    @FXML
    private void NewProductButton(ActionEvent event) throws IOException {
        Parent home_page_parent = FXMLLoader.load(getClass().getResource("NewProductController.fxml"));
        Scene home_page_scene = new Scene(home_page_parent);
        Stage app_stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        app_stage.setScene(home_page_scene);
        app_stage.show();
    }

    @FXML
    private void NewSupplierButton (ActionEvent event) throws IOException{

        Parent home_page_parent = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("NewSupplierController.fxml")));
        Scene home_page_scene = new Scene(home_page_parent);
        Stage app_stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        app_stage.setScene(home_page_scene);
        app_stage.show();

    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        LinkedList<String> Produtos = m.getAllProductnames (d);
        ObservableList<String> obsProdutos = FXCollections.observableArrayList(Produtos);
        FiltroProduto.setItems(obsProdutos);
    }
}
