package gui.gui_bd;

import backend.User;
import database.*;
import frontend.*;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;


public class FichaController implements Initializable {

    @FXML
    private Label UserName;
    @FXML
    private Label Name;
    @FXML
    private Label Sex;
    @FXML
    private Label Role;
    @FXML
    private Label Email;
    @FXML
    private Label Contact;

    TransmissionData TU = TransmissionData.getInstance();

    front f = new front();
    DB d = DB.getInstance();

    User U = TU.getUserLogin();
    String Username = U.getName();
    String pp = "pp";



    @FXML   //Ir para a página new user
    private void BackButton(ActionEvent event) throws IOException {
        Parent home_page_parent = FXMLLoader.load(getClass().getResource("HomeController.fxml"));
        Scene home_page_scene = new Scene(home_page_parent);
        Stage app_stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        app_stage.setScene(home_page_scene);
        app_stage.show();
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        UserName.setText(Username);
        Name.setText(U.getName());
        Sex.setText(String.valueOf((Character) U.getSex()));
        Role.setText(U.getRole());
        Email.setText(U.getEmail());
        Contact.setText(U.getContact());
    }
}
